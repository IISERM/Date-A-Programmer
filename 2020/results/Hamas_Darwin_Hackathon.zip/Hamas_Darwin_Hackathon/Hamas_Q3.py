import numpy as np
import matplotlib.pyplot as plt
import random

w, h = 256, 256
data = np.zeros((h, w, 3), dtype=np.uint8)
# data[::0] is death status
# data[::1] is ground
# data[::2] is individual
for i in range(len(data)):
    for j in range(len(data[0])):
        data[i][j][0] = 1

l, c = 256, 2
individuals = np.zeros((w, h, l, c), dtype=np.uint8)

# initializing
individuals = np.random.choice([0, 1], size=(256, 256, 256, 2), p=[0.5, 0.5])


def get_phenotype(genotype):
    """
    takes l*c (256*2) array
    gives number for image
    """
    total = 0
    for i in range(len(genotype)):
        # Nice use of OR gate
        total = total + (genotype[i][0] | genotype[i][1])
    return total


def update_data():
    for i in range(len(individuals)):
        for j in range(len(individuals[0])):
            data[i][j][2] = get_phenotype(individuals[i][j])  # V. Clean


def update_ground():
    for i in range(len(data)):
        for j in range(len(data[0])):
            data[i][j][1] = data[i][j][1] + 2.55  # Ground changes spatially


def kill():          # death is less violent than kill :P
    for i in range(len(data)):
        for j in range(len(data[0])):
            diff = abs(data[i][j][1] - data[i][j][2])
            if random.random() < ((0.85 / 255) * diff + 0.05):
                data[i][j][0] = 0
                individuals[i][j] = np.zeros((256, 2), dtype=np.uint8)
            else:
                data[i][j][0] = 1
    update_data()


def reproduce():
    for i in range(len(data)):
        for j in range(len(data[0])):
            if data[i][j][0] == 1:
                x, y = pick_neighbour(i, j)
                if data[x][y][0] == 0:
                    data[x][y][2] = data[i][j][2]
                    individuals[x][y] = individuals[i][j]
                else:
                    mate(i, j, x, y)
    update_data()


def mate(i, j, x, y):
    progeny1 = np.zeros((256, 2), dtype=np.uint8)
    progeny2 = np.zeros((256, 2), dtype=np.uint8)
    for locus in range(len(progeny1)):

        progeny1[locus] = np.array(
            individuals[i][j][locus][0] if random.random(
            ) < 0.5 else individuals[i][j][locus][1],
            individuals[x][y][locus][0] if random.random() < 0.5
            else individuals[x][y][locus][1])

        progeny2[locus] = np.array(
            individuals[i][j][locus][0] if random.random(
            ) < 0.5 else individuals[i][j][locus][1],
            individuals[x][y][locus][0] if random.random() < 0.5
            else individuals[x][y][locus][1])

        # What if the same gene is selected again?
        # Choosing the genes for the first fixes it for the second too
    individuals[i][j] = progeny1
    individuals[x][y] = progeny2

# def pick_neighbour(x,y):
# 	x_new = x+1 if random.random() < 0.5 else x-1
# 	y_new = y+1 if random.random() < 0.5 else y-1
# 	if (x<255 and y<255) and (x>=0 and y >=0):
# 		return (x_new,y_new)
# 	else:
# 		pick_neighbour(x,y)


def pick_neighbour(x, y):
    x_val = []
    y_val = []
    if x - 1 < 256 and x - 1 >= 0:
        x_val.append(x - 1)
    if y - 1 < 256 and y - 1 >= 0:
        y_val.append(y - 1)
    if x + 1 < 256 and x + 1 >= 0:
        x_val.append(x + 1)
    if y + 1 < 256 and y + 1 >= 0:
        y_val.append(y + 1)
    return (random.choice(x_val), random.choice(y_val))


def main():

    update_data()
    for generation in range(100):
        print("On generation %d" % (generation))
        kill()
        reproduce()
        update_ground()
        plt.imshow(data, interpolation='nearest')
        plt.savefig("/home/dl/Codes/Darwin/lol/%d.png" % (generation))


if __name__ == '__main__':
    main()
