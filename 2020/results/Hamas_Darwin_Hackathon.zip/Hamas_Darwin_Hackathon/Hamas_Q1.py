h = open("ATGC.txt")
bases = dict()

for line in h:
	for base in line.strip():
		bases[base] = bases.get(base, 0) + 1

for key, value in bases.items():
	print("Number of %s = %d" %(key, value))

h.close()