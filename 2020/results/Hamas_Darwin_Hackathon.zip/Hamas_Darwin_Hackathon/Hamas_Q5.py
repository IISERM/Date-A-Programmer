import matplotlib.pyplot as plt

# This code assumes that the Files Session1.csv,
# Session2.csv & Session3.csv is present in the
# working directory with the remarks column removed manually

common_name_col = 4
time_col = 13
date_col = 12


def convert_to_minutes(time_str):
    [H, M] = time_str.split(":")
    return int(H) * 60 + int(M)


def get_real_time(time_str, date_str):
    if date_str == "01/22/2020":
        return convert_to_minutes(time_str)
    if date_str == "01/30/2020":
        return (convert_to_minutes(time_str) + 8 * 24 * 60)
    if date_str == "02/08/2020":
        return (convert_to_minutes(time_str) + 17 * 24 * 60)


def Get_count(real_obs_time):
    csv = open("Merged.csv", "rt")
    known_birds = []
    for row_str in csv:
        row = row_str.split(",")
        if row[0] != "Session Name":
            row_time = get_real_time(row[time_col], row[date_col])
            # println("\n\nReal Row time is:",row_time)
            # println("Real Obs time is:",real_obs_time)
            if row_time <= real_obs_time and (
                    row[common_name_col] not in known_birds):
                # print(row[common_name_col],"is first sighted at",row_time)
                known_birds.append(row[common_name_col])
    csv.close()
    return(len(known_birds))


if __name__ == "__main__":

    # Code to merge files
    fout = open("Merged.csv", "w")
    for num in range(1, 4):
        print("Merging file", num, "...")
        f = open("session" + str(num) + ".csv")
        for line in f:
            fout.write(line)
        f.close()
    fout.close()

    # Code to generate data points
    Species_count = []
    time_count = []
    file = open("Merged.csv")
    for line in file:
        row = line.split(",")
        # print(row)
        if row[0] != "Session Name":
            real_row_time = get_real_time(row[time_col], row[date_col])
            time_count.append(real_row_time)
            Species_count.append(Get_count(real_row_time))
    plt.plot(time_count, Species_count)
    plt.ylabel("Number of Species Discovered")
    plt.xlabel("Time in minutes (Starting from 00:00 01/22/2020)")
    plt.show()
