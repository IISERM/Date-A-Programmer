
def compare_two(one, two):
    """
    take two lists
    returns 1/0
    """
    diff = 0
    for i in range(len(one)):
        if one[i] != two[i]:
            diff = diff + 1
    if diff > 2:
        return False
    else:
        return True


def find_species(sequence):
    """
    takes list
    return species
    """
    for j, cur_call in enumerate(known_calls):
        if compare_two(cur_call, sequence):
            return known_sp[j]
    return False


# Generate known calls matrix
known_calls = []
known_sp = []
hk = open("species.txt")
for line in hk:
    line = line.strip()
    known_sp.append(line.split(":")[0].strip())
    known_calls.append(line.split(":")[1].strip().split("-"))
hk.close()

count = 0  # new species name

# BEL check
print("Checking if BEL is correct...")
for k, bel1 in enumerate(known_calls):
    for m, bel2 in enumerate(known_calls[k + 1:], k + 1):
        if compare_two(bel1, bel2):
            print("BEL is wrong for %s and %s" % (known_sp[k], known_sp[m]))
    else:
        print("BEL is correct for %s" % (known_sp[k]))


h = open("calls.txt")

apna_species = dict()  # XD

for i, line in enumerate(h):
    line = line.strip().split("-")
    cur_species = find_species(line)
    if cur_species is False:  # found new species. Update known species
        count = count + 1
        cur_species = count
        known_sp.append(str(cur_species))
        known_calls.append(line)
    apna_species[cur_species] = apna_species.get(cur_species, 0) + 1


# print

out = open("out.txt", "w")
n_s = 0
for spici, indi in apna_species.items():
    out.write("%d individual(s) of species %s\n" % (indi, str(spici)))
    n_s = n_s + 1

out.write(
    "Total number of species (and also number of identifiable species) =" +
    str(n_s) + "\n")
out.close()
