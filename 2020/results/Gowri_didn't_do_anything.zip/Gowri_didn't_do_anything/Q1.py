A = 0
C = 0
U = 0
G = 0
with open('darwin1.txt') as f:
    while True:
        c = f.read(1)
        if c == 'A':
            A += 1
        elif c == 'C':
            C += 1
        elif c == 'U':
            U += 1
        elif c == 'G':
            G += 1
        elif not c:
            break
print('A=', A, 'C=', C, 'U=', U, 'G=', G)
