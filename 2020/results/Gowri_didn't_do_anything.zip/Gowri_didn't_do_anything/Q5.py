import matplotlib.pyplot as plt
import datetime
with open('session1.csv') as f:
    lines = [list(line.rstrip('\n').split(","))for line in f]
species = []
num = 0
time = []
sp = []
for i in range(1, len(lines)):
    if lines[i][6] not in species:
        species.append(lines[i][6])
        num = num + 1
        sp.append(num)
        my_date = datetime.datetime.strptime(
            str(lines[i][-2]) + str(lines[i][-1]), "%m/%d/%Y%H:%M")
        time.append(my_date)
plt.plot(time, sp)
plt.xlabel('time/date')
plt.ylabel('number of species')
plt.show()
