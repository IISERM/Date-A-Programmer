new = ""
with open('protein.txt', 'r') as f:
    while True:
        i = f.read(1)
        if i == 'A':
            new += 'U'
        elif i == 'C':
            new += 'G'
        elif i == 'T':
            new += 'A'
        elif i == 'G':
            new += 'C'
        elif not i:
            break
seq = new
table = {
    "AAA": "A01", "UAA": "A02", "GAA": "A03", "CAA": "A04", "AUA": "A05",
    "UUA": "A06", "GUA": "A07", "CUA": "A08", "AGA": "A09", "UGA": "A10",
    "GGA": "A11", "CGA": "A12", "ACA": "A13", "UCA": "A14", "GCA": "A15",
    "CCA": "A16", "AAU": "A17", "UAU": "A18", "GAU": "A19", "CAU": "A20",
    "AUU": "A21", "UUU": "A22", "GUU": "A23", "CUU": "A24", "AGU": "A25",
    "UGU": "A26", "GGU": "A27", "CGU": "A28", "ACU": "A29", "UCU": "A30",
    "GCU": "A31", "CCU": "A32", "AAG": "A33", "UAG": "A34", "GAG": "A35",
    "CAG": "A36", "AUG": "A37", "UUG": "A38", "GUG": "A39", "CUG": "A40",
    "AGG": "A41", "UGG": "A42", "GGG": "A43", "CGG": "A44", "ACG": "A45",
    "UCG": "A46", "GCG": "A47", "CCG": "A48", "AAC": "A49", "UAC": "A50",
    "GAC": "A51", "CAC": "A52", "AUC": "A53", "UUC": "A54", "GUC": "A55",
    "CUC": "A56", "AGC": "A57", "UGC": "A58", "GGC": "A59", "CGC": "A60",
    "ACC": "A61", "UCC": "A62", "GCC": "A63", "CCC": "A64"}
protein = ""
if len(seq) % 3 == 0:
    for i in range(0, len(seq), 3):
        codon = seq[i:i + 3]
        protein += table[codon]
f = open('proteinnew.txt', 'w')
f.write(protein)
f.close()
