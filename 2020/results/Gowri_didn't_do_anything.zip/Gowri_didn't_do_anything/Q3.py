import numpy as np
import matplotlib.pyplot as plt
import random

fig, ax = plt.subplots(1)

n = 20
# define ground
ground = np.ones([n, n])
for i in range(n):
    for j in range(n):
        ground[i][j] = j * 256 / n
'''
ax.matshow(ground, cmap=plt.cm.Blues)
for i in range(n):
    for j in range(n):
        c = ground[j][i]
        ax.text(i, j, str(c), va='center', ha='center')
ax.set_title('Ground')
'''

# defining genotypes of organisms
organisms = np.array(np.zeros([n, n, 256]))
for i in range(n):
    for j in range(n):
        if np.random.randint(2) == 1:
            for k in range(256):
                organisms[i][j][k] = np.random.randint(2)
        else:
            organisms[i][j] = None


def pheno(organisms, n):
    phenotype = np.array(np.zeros([n, n]))
    for i in range(n):
        for j in range(n):
            phenotype[i][j] = np.sum(organisms[i, j, :])
    return phenotype


phenotype = pheno(organisms, n)


def death(ground, phenotype, organisms, n):
    phenotype[np.isnan(phenotype)] = 0
    for i in range(n):
        for j in range(n):
            diff = np.abs(ground[i][j] - phenotype[i][j])
            # for normalising difference in range 5-90%
            if diff * 90 / 256 < 5:
                diff = 5
            else:
                diff = int(diff * 90 / 256)
            # calculating the death probability
            l1 = list(np.ones(diff))
            l2 = list(np.zeros(100 - diff))
            l1 = l1 + l2
            random.shuffle(l1)
            if l1[np.random.randint(100)] == 1:
                organisms[i][j] = None              # GREAT use of none
    return organisms


# run for 100 gen
for m in range(100):
    organisms = death(ground, phenotype, organisms, n)
    phenotype = pheno(organisms, n)
    ax.matshow(phenotype, cmap=plt.cm.Blues)
    ax.set_title(m)
    plt.savefig("gen{m}.png".format(m=m))


# couldn't do the reproduction part
