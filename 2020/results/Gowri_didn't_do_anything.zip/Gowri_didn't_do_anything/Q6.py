
standard_calls = {
    'Fulvous whistling duck': 'wsl-bzz-chp-trl-wsl-clk-trl-trl-chp-bzz-wsl-bzz-wsl-wsl-wsl-wsl-trl-wsl-trl-chp',
    'Lesser whistling duck': 'wsl-rst-trl-clk-bzz-chp-wsl-rst-trl-trl-clk-wsl-clk-chp-rst-clk-clk-bzz-bzz-clk',
    'Red-breasted goose': 'trl-wsl-wsl-wsl-rst-chp-trl-wsl-clk-rst-clk-wsl-chp-clk-bzz-clk-bzz-wsl-wsl-trl',
    'Bar-headed goose': 'wsl-wsl-trl-trl-clk-trl-clk-clk-rst-wsl-bzz-rst-trl-bzz-clk-chp-wsl-bzz-bzz-clk',
    'Graylag goose': 'chp-bzz-bzz-bzz-clk-wsl-bzz-trl-bzz-chp-bzz-wsl-clk-wsl-bzz-trl-clk-rst-trl-bzz',
    'Taiga bean-goose': 'clk-bzz-wsl-rst-wsl-bzz-chp-rst-wsl-rst-wsl-clk-trl-bzz-chp-trl-clk-rst-wsl-wsl',
    'Tundra bean-goose': 'trl-clk-bzz-rst-wsl-bzz-wsl-trl-bzz-wsl-rst-rst-rst-rst-wsl-chp-rst-clk-clk-trl',
    'Greater white-fronted goose': 'rst-chp-chp-wsl-chp-wsl-chp-rst-rst-wsl-bzz-clk-clk-wsl-clk-wsl-clk-trl-wsl-clk',
    'Lesser white-fronted goose': 'clk-chp-bzz-chp-clk-bzz-chp-chp-wsl-wsl-clk-rst-rst-wsl-wsl-clk-rst-wsl-trl-bzz',
    'Mute swan': 'wsl-trl-trl-bzz-trl-trl-bzz-bzz-rst-clk-trl-clk-chp-trl-clk-wsl-chp-trl-bzz-trl',
    'Tundra swan': 'clk-wsl-bzz-trl-clk-rst-rst-rst-clk-trl-wsl-rst-wsl-chp-clk-clk-clk-clk-chp-chp',
    'Whooper swan': 'rst-rst-clk-clk-bzz-rst-wsl-bzz-trl-bzz-bzz-rst-chp-trl-wsl-trl-bzz-bzz-wsl-chp',
    'Knob-billed duck': 'rst-clk-chp-trl-clk-wsl-chp-rst-clk-bzz-chp-trl-bzz-bzz-chp-trl-chp-rst-bzz-trl',
    'Common shelduck ': 'trl-trl-trl-trl-wsl-chp-trl-trl-trl-trl-trl-chp-bzz-wsl-clk-rst-trl-trl-rst-rst',
    'Ruddy shelduck': 'clk-trl-rst-chp-trl-bzz-bzz-clk-clk-bzz-rst-bzz-rst-chp-bzz-bzz-rst-trl-trl-trl',
    'White-winged duck': 'clk-chp-bzz-chp-chp-chp-chp-bzz-clk-trl-trl-rst-trl-trl-wsl-chp-clk-trl-wsl-chp',
    'Mandarin duck': 'bzz-bzz-chp-wsl-rst-chp-wsl-clk-rst-clk-chp-rst-wsl-bzz-trl-rst-bzz-wsl-rst-chp'}


species = 1000
with open('calls.txt') as f:
    lines = [list(line.rstrip('\n').split("-"))for line in f]

    for i in range(0, len(lines)):
        for call in standard_calls.values():
            temp = 0
            for x, y in zip(lines[i], list(call.split("-"))):
                if x == y:
                    temp = temp + 1
                if temp >= 18:
                    species = species - 1
                    break

print('number of species =', species)

print('each species has one individual in data')


# to check if two species are same in the standard calls itself
species = 17
for call1 in standard_calls.values():
    for call2 in standard_calls.values():  # unnecessary multiple checks
        temp = 0
        for x, y in zip(list(call1.split("-")), list(call2.split("-"))):
            if x == y:
                temp = temp + 1
        if temp != 20 and temp >= 18:
            species -= 1
print('Number of identifiable species in standard_calls=', species)

print("so we can say that all the species are different in standard calls and\
 only those will be identifiable in the given data, \
 even if in the data also each bird is of different species.")
